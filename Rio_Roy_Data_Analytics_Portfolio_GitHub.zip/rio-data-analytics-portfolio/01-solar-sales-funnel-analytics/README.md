# Solar Sales Funnel & Operations Analytics

I built this project to practice the kind of business analytics work used in fast-moving sales and operations teams: recurring reporting, funnel analysis, ad-hoc investigation, dashboards and process recommendations.

The data is **synthetic**. It is not Enpal data and does not represent Enpal's real performance.

## Business question

A weekly management report shows that lead-to-contract conversion dropped in the latest four weeks.

My goal was to answer:

- Where in the funnel did performance weaken?
- Did the acquisition mix change?
- Did slower lead response contribute?
- Which teams/sources should management look at first?
- What actions could improve conversion?

## Dataset

50,000 simulated renewable-energy sales leads from January to August 2026.

The funnel is:

`Lead -> Contacted -> Qualified -> Consultation -> Offer -> Contract -> Installation`

Main dimensions:
- lead source
- region
- product
- sales team
- lead score
- response time
- funnel-stage flags
- revenue and gross margin

## What I found

- Lead-to-contract conversion moved from **7.39%** before the latest four weeks to **5.31%** in the recent period.
- Median response time moved from **19 minutes** to **34 minutes**.
- Paid Social grew from **17.7%** of leads to **31.2%**, while it is one of the weaker-converting acquisition sources in this simulated dataset.
- The recent period also shows weaker consultation-to-offer progression, so the issue is not explained by acquisition mix alone.

## Recommendation

I would treat the decline as a combined **lead-quality + response-time + funnel execution** problem.

1. Prioritise high-score leads and set a response-time SLA.
2. Review acquisition spend using end-to-end conversion, not lead volume alone.
3. Monitor stage conversion weekly so the team can see exactly where a drop begins.
4. Give managers a short daily/weekly report with targets, variance and the main driver behind movement.

## Tools

- Excel: management reporting, KPI calculations, pivot-style analysis
- SQL: recurring reporting and ad-hoc business questions
- Power BI: dashboard model and DAX measures
- Python: data validation and reproducible analysis


## Automated KPI monitor

I also added a small weekly monitoring script using Isolation Forest. It checks conversion, response time and other operating KPIs for unusual patterns and writes a short manager-facing alert.

I would not use the model to make an automatic business decision. Its purpose is to tell an analyst where to investigate first.

See `automation/kpi_monitor.py`.

## Repository structure

```text
data/       synthetic CRM-style dataset
sql/        schema + analysis queries
notebooks/  reproducible Python analysis
powerbi/    DAX measures and dashboard plan
images/     charts used in the case study
docs/       business story and interview notes
```

## Dashboard preview

![Weekly conversion](images/weekly_conversion.png)

![Sales funnel](images/sales_funnel.png)

## Notes

This is a portfolio simulation built from public job requirements and a realistic residential-energy sales workflow. The purpose is to show how I structure a business problem, work with data, and turn findings into actions.
