# Power BI measures

Use the CSV in `data/` as the model table `Leads`.

```DAX
Leads = COUNTROWS('Leads')

Contacted = SUM('Leads'[contacted])
Qualified = SUM('Leads'[qualified])
Consultations = SUM('Leads'[consultation_attended])
Offers = SUM('Leads'[offer_made])
Contracts = SUM('Leads'[contract_signed])

Lead to Contract % = DIVIDE([Contracts], [Leads])

Contact Rate % = DIVIDE([Contacted], [Leads])

Qualified to Consultation % =
DIVIDE([Consultations], [Qualified])

Consultation to Offer % =
DIVIDE([Offers], [Consultations])

Offer to Contract % =
DIVIDE([Contracts], [Offers])

Revenue EUR = SUM('Leads'[revenue_eur])

Gross Margin EUR = SUM('Leads'[gross_margin_eur])

Median Response Time =
MEDIAN('Leads'[response_time_min])

Cancellation % =
DIVIDE(
    SUM('Leads'[cancelled]),
    [Contracts]
)
```

## Suggested dashboard pages

**1. Management Overview**
- KPI cards: Leads, Contracts, Lead-to-Contract %, Revenue EUR, Median Response Time
- Weekly conversion line chart
- Lead source conversion bar chart
- Slicers: region, product, sales team, lead source

**2. Funnel Diagnostic**
- Funnel: Leads -> Contacted -> Qualified -> Consultation -> Offer -> Contract
- Conversion by stage
- Conversion by response-time bucket
- Team-level stage conversion

**3. Acquisition & Operations**
- Lead-source mix by week
- Revenue by product and source
- Response time by sales team
- High-score open leads table
