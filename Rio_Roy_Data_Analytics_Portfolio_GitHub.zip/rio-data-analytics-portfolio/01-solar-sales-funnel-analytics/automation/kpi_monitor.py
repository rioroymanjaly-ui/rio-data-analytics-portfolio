"""
Weekly KPI monitor for the synthetic solar sales funnel project.

What it does:
1. Loads the CRM-style synthetic dataset.
2. Builds weekly KPIs.
3. Uses Isolation Forest to detect unusual weekly operating patterns.
4. Writes a CSV with anomaly flags and a short manager-facing alert summary.

This is portfolio code using simulated data only.
"""

from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest

BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "data" / "synthetic_solar_sales_funnel.csv"
OUTPUT = BASE / "automation"

def build_weekly_kpis(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["lead_date"] = pd.to_datetime(df["lead_date"])
    df["week"] = df["lead_date"].dt.to_period("W-MON").dt.start_time

    weekly = (
        df.groupby("week")
          .agg(
              leads=("lead_id", "count"),
              contacted=("contacted", "sum"),
              qualified=("qualified", "sum"),
              consultations=("consultation_attended", "sum"),
              offers=("offer_made", "sum"),
              contracts=("contract_signed", "sum"),
              revenue_eur=("revenue_eur", "sum"),
              avg_response_min=("response_time_min", "mean"),
          )
          .reset_index()
    )

    weekly["contact_rate"] = weekly["contacted"] / weekly["leads"]
    weekly["lead_to_contract"] = weekly["contracts"] / weekly["leads"]
    weekly["consult_to_offer"] = (
        weekly["offers"] / weekly["consultations"].replace(0, np.nan)
    )
    weekly["revenue_per_lead"] = weekly["revenue_eur"] / weekly["leads"]

    return weekly

def detect_anomalies(weekly: pd.DataFrame) -> pd.DataFrame:
    features = [
        "contact_rate",
        "lead_to_contract",
        "consult_to_offer",
        "avg_response_min",
        "revenue_per_lead",
    ]

    X = weekly[features].replace([np.inf, -np.inf], np.nan).fillna(0)

    model = IsolationForest(
        n_estimators=250,
        contamination=0.12,
        random_state=42,
    )

    weekly = weekly.copy()
    weekly["anomaly_flag"] = model.fit_predict(X)
    weekly["anomaly_score"] = model.decision_function(X)

    return weekly

def write_manager_summary(result: pd.DataFrame) -> None:
    latest = result.iloc[-1]
    previous_4 = result.iloc[-5:-1]

    baseline_conversion = previous_4["lead_to_contract"].mean()
    baseline_response = previous_4["avg_response_min"].mean()

    conversion_change_pp = (
        latest["lead_to_contract"] - baseline_conversion
    ) * 100
    response_change = (
        latest["avg_response_min"] - baseline_response
    )

    lines = [
        "# Weekly KPI Monitor",
        "",
        f"Week: {latest['week'].date()}",
        "",
        f"- Lead-to-contract conversion: {latest['lead_to_contract']:.2%}",
        f"- Change vs prior 4-week average: {conversion_change_pp:+.2f} pp",
        f"- Average response time: {latest['avg_response_min']:.1f} min",
        f"- Change vs prior 4-week average: {response_change:+.1f} min",
        f"- Isolation Forest anomaly flag: {'REVIEW' if latest['anomaly_flag'] == -1 else 'Normal'}",
        "",
    ]

    if latest["anomaly_flag"] == -1:
        lines += [
            "## Suggested review",
            "",
            "The latest week has an unusual KPI pattern compared with the rest of the series.",
            "Check lead-source mix, response-time distribution, and stage conversion before taking action.",
        ]
    else:
        lines += [
            "## Suggested review",
            "",
            "No major anomaly was detected in the latest week.",
            "Continue monitoring conversion and response time against the four-week baseline.",
        ]

    (OUTPUT / "latest_manager_alert.md").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )

def main():
    df = pd.read_csv(DATA)
    weekly = build_weekly_kpis(df)
    result = detect_anomalies(weekly)

    result.to_csv(OUTPUT / "weekly_kpi_monitor.csv", index=False)
    write_manager_summary(result)

    print(
        result[
            [
                "week",
                "lead_to_contract",
                "avg_response_min",
                "anomaly_flag",
                "anomaly_score",
            ]
        ].tail(8).to_string(index=False)
    )

if __name__ == "__main__":
    main()
