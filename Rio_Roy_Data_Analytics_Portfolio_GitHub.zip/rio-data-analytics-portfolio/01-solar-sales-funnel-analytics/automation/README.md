# KPI monitor

I added this after the main funnel analysis because I wanted the reporting workflow to do more than show historical numbers.

The script builds weekly KPIs and uses an Isolation Forest model to flag weeks that look unusual across:

- lead-to-contract conversion
- contact rate
- consultation-to-offer conversion
- average response time
- revenue per lead

It then writes:
- `weekly_kpi_monitor.csv`
- `latest_manager_alert.md`

The alert is intentionally short. In a real company I would use it as a prompt for investigation, not as an automatic business decision.

Run it with:

```bash
python automation/kpi_monitor.py
```

The data in this repository is synthetic.
