# Weekly KPI Monitor

Week: 2026-08-25

- Lead-to-contract conversion: 5.45%
- Change vs prior 4-week average: -0.30 pp
- Average response time: 41.9 min
- Change vs prior 4-week average: +2.9 min
- Isolation Forest anomaly flag: REVIEW

## Suggested review

The latest week has an unusual KPI pattern compared with the rest of the series.
Check lead-source mix, response-time distribution, and stage conversion before taking action.