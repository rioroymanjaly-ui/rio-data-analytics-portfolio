-- Synthetic renewable-energy sales funnel
-- This project uses simulated data only. It is not Enpal internal data.

CREATE TABLE leads (
    lead_id VARCHAR(20) PRIMARY KEY,
    lead_date DATE NOT NULL,
    region VARCHAR(50),
    product VARCHAR(50),
    lead_source VARCHAR(50),
    sales_team VARCHAR(30),
    lead_score INT,
    response_time_min INT,
    contacted TINYINT,
    qualified TINYINT,
    consultation_booked TINYINT,
    consultation_attended TINYINT,
    offer_made TINYINT,
    contract_signed TINYINT,
    cancelled TINYINT,
    installed TINYINT,
    contact_date DATE NULL,
    qualification_date DATE NULL,
    consultation_date DATE NULL,
    offer_date DATE NULL,
    contract_date DATE NULL,
    installation_date DATE NULL,
    days_to_contract INT NULL,
    revenue_eur DECIMAL(12,2),
    gross_margin_eur DECIMAL(12,2)
);
