-- 1. Weekly management report
SELECT
    DATE_FORMAT(lead_date, '%x-%v') AS year_week,
    COUNT(*) AS leads,
    SUM(contacted) AS contacted,
    SUM(qualified) AS qualified,
    SUM(consultation_attended) AS consultations,
    SUM(offer_made) AS offers,
    SUM(contract_signed) AS contracts,
    ROUND(100.0 * SUM(contract_signed) / COUNT(*), 2) AS lead_to_contract_pct,
    ROUND(SUM(revenue_eur), 2) AS revenue_eur
FROM leads
GROUP BY DATE_FORMAT(lead_date, '%x-%v')
ORDER BY year_week;

-- 2. Sales-funnel performance by acquisition channel
SELECT
    lead_source,
    COUNT(*) AS leads,
    SUM(contract_signed) AS contracts,
    ROUND(100.0 * SUM(contract_signed) / COUNT(*), 2) AS conversion_pct,
    ROUND(AVG(response_time_min), 1) AS avg_response_min,
    ROUND(SUM(revenue_eur), 2) AS revenue_eur
FROM leads
GROUP BY lead_source
ORDER BY conversion_pct DESC;

-- 3. Does response speed matter?
SELECT
    CASE
        WHEN response_time_min <= 15 THEN '<=15 min'
        WHEN response_time_min <= 30 THEN '16-30 min'
        WHEN response_time_min <= 60 THEN '31-60 min'
        WHEN response_time_min <= 120 THEN '61-120 min'
        ELSE '>120 min'
    END AS response_bucket,
    COUNT(*) AS leads,
    SUM(contract_signed) AS contracts,
    ROUND(100.0 * SUM(contract_signed) / COUNT(*), 2) AS conversion_pct
FROM leads
GROUP BY response_bucket
ORDER BY MIN(response_time_min);

-- 4. Team-level bottleneck check
SELECT
    sales_team,
    COUNT(*) AS leads,
    ROUND(100.0 * SUM(contacted) / COUNT(*), 2) AS contact_pct,
    ROUND(100.0 * SUM(consultation_attended) / NULLIF(SUM(qualified),0), 2) AS qualified_to_consult_pct,
    ROUND(100.0 * SUM(offer_made) / NULLIF(SUM(consultation_attended),0), 2) AS consult_to_offer_pct,
    ROUND(100.0 * SUM(contract_signed) / NULLIF(SUM(offer_made),0), 2) AS offer_to_contract_pct
FROM leads
GROUP BY sales_team
ORDER BY offer_to_contract_pct DESC;

-- 5. High-priority open leads for a sales team
SELECT
    lead_id, lead_date, region, product, lead_source, sales_team,
    lead_score, response_time_min
FROM leads
WHERE contract_signed = 0
  AND lead_score >= 75
ORDER BY lead_score DESC, response_time_min ASC
LIMIT 50;

-- 6. Ad-hoc question: where did recent conversion deteriorate?
SELECT
    lead_source,
    CASE WHEN lead_date >= '2026-08-03' THEN 'recent_4_weeks' ELSE 'earlier' END AS period,
    COUNT(*) AS leads,
    ROUND(100.0 * SUM(contract_signed) / COUNT(*), 2) AS conversion_pct
FROM leads
GROUP BY lead_source, period
ORDER BY lead_source, period;
