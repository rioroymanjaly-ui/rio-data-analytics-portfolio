# Project story

## Situation
A management report showed a recent fall in sales conversion.

## Task
Find the main drivers, identify where the sales funnel weakened, and propose practical actions.

## Analysis
I compared the latest four weeks with the earlier period, then cut performance by acquisition source, response-time bucket, team and funnel stage.

The recent conversion rate was 5.31% versus 7.39% earlier.
Median response time increased from 19 to 34 minutes.
Paid Social's share of incoming leads increased from 17.7% to 31.2%.

I also checked whether the decline could be explained by one stage alone. The answer was no: the simulated issue included both lower-quality acquisition mix and a weaker consultation-to-offer step.

## Recommendation
- Create a daily high-score lead queue.
- Set a response-time SLA for priority leads.
- Track lead source by end-to-end conversion and revenue, not only lead count.
- Add weekly stage-conversion reporting with threshold alerts.
- Review Team C's recent response time and process load.

## What I would do next
If this were a live business environment, I would validate the findings with CRM definitions, campaign spend, staffing levels and sales-team context before changing budget or targets.
