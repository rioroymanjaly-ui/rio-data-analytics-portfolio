# Interview notes

## 30-second project explanation

I built a synthetic renewable-energy sales funnel with 50,000 CRM-style leads. The business problem was a recent decline in lead-to-contract conversion. I created recurring KPI reporting, analysed the funnel by acquisition source, response time and team, and found that the drop was driven by a worse lead-source mix, slower response times and weaker progression from consultation to offer. I then translated that into operational recommendations such as response-time SLAs, lead prioritisation and stage-level weekly reporting.

## If they ask: why synthetic data?

I wanted to practise the business workflow without pretending I had access to confidential company data. I designed the dataset so that the root cause was not obvious from the top-line KPI and then worked through the diagnosis.

## If they ask: why Excel when you know Python?

For a recurring management report, Excel can be the fastest tool for a team to inspect, update and share. I would use SQL for repeatable extraction, Excel for quick operational analysis and stakeholder-friendly reporting, and Power BI when the reporting needs a scalable interactive dashboard.

## Questions I should be ready to answer

1. How did you define each funnel stage?
2. Which KPI did you look at first and why?
3. How did you know the conversion decline was not just random variation?
4. Why can response time be correlated with conversion without proving causation?
5. Which action would you test first?
6. What would you need from a real CRM before trusting the recommendation?
7. How would you automate the weekly report?
8. How would you handle a manager asking for an urgent ad-hoc cut of the data?
