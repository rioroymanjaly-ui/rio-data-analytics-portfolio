# Solar Energy Forecasting

Python, pandas, scikit-learn

Verified project results from my existing portfolio records:

- 196,777 observations analysed
- Linear Regression: R² 0.847, MAE 242 Wh, RMSE 410 Wh
- Random Forest: R² 0.914, MAE 134 Wh, RMSE 308 Wh
- Random Forest produced the stronger out-of-sample result

The original source notebook/dataset was not recovered from my current file library, so this folder intentionally does **not** recreate or invent the code.
