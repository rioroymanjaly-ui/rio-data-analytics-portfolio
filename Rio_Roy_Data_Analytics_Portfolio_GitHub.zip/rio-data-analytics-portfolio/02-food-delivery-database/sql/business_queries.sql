-- Business question 1: Which restaurant makes the most money?
SELECT
    r.RestaurantName,
    COUNT(o.OrderID) AS TotalOrders,
    SUM(o.TotalAmount) AS TotalRevenue
FROM Restaurants r
JOIN Orders o ON r.RestaurantID = o.RestaurantID
GROUP BY r.RestaurantName
ORDER BY TotalRevenue DESC;

-- Business question 2: What kind of spenders are our customers?
SELECT
    c.CustomerName,
    SUM(o.TotalAmount) AS TotalSpent,
    CASE
        WHEN SUM(o.TotalAmount) >= 30 THEN 'High Spender'
        WHEN SUM(o.TotalAmount) >= 15 THEN 'Medium Spender'
        ELSE 'Low Spender'
    END AS CustomerCategory
FROM Customers c
JOIN Orders o ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerName;

-- Business question 3: Which rider delivered the most food?
SELECT
    r.RiderName,
    COUNT(d.DeliveryID) AS TotalDeliveries,
    RANK() OVER (ORDER BY COUNT(d.DeliveryID) DESC) AS RiderRank
FROM Riders r
JOIN Deliveries d ON r.RiderID = d.RiderID
GROUP BY r.RiderName;

-- Query-performance improvement from the assignment
CREATE INDEX idx_orders_restaurantid ON Orders(RestaurantID);
