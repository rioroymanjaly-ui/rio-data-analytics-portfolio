-- Food Delivery Database
-- Reconstructed from my submitted MSc assignment structure.

CREATE DATABASE IF NOT EXISTS food_delivery;
USE food_delivery;

CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CustomerName VARCHAR(100),
    Phone VARCHAR(30),
    Email VARCHAR(120),
    Address VARCHAR(255)
);

CREATE TABLE Restaurants (
    RestaurantID INT PRIMARY KEY,
    RestaurantName VARCHAR(120),
    Location VARCHAR(150),
    CuisineType VARCHAR(80),
    Rating DECIMAL(2,1)
);

CREATE TABLE Riders (
    RiderID INT PRIMARY KEY,
    RiderName VARCHAR(100),
    Phone VARCHAR(30),
    VehicleType VARCHAR(50),
    RiderStatus VARCHAR(50)
);

CREATE TABLE FoodItems (
    FoodItemID INT PRIMARY KEY,
    FoodName VARCHAR(120),
    Category VARCHAR(80),
    Price DECIMAL(10,2),
    Availability BOOLEAN,
    RestaurantID INT,
    FOREIGN KEY (RestaurantID) REFERENCES Restaurants(RestaurantID)
);

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    OrderDate DATE,
    OrderStatus VARCHAR(50),
    TotalAmount DECIMAL(10,2),
    CustomerID INT,
    RestaurantID INT,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (RestaurantID) REFERENCES Restaurants(RestaurantID)
);

CREATE TABLE OrderItems (
    OrderItemID INT PRIMARY KEY,
    Quantity INT,
    ItemPrice DECIMAL(10,2),
    OrderID INT,
    FoodItemID INT,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (FoodItemID) REFERENCES FoodItems(FoodItemID)
);

CREATE TABLE Payments (
    PaymentID INT PRIMARY KEY,
    PaymentMethod VARCHAR(50),
    PaymentStatus VARCHAR(50),
    PaymentDate DATE,
    Amount DECIMAL(10,2),
    OrderID INT,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);

CREATE TABLE Deliveries (
    DeliveryID INT PRIMARY KEY,
    DeliveryStatus VARCHAR(50),
    PickupTime DATETIME,
    DeliveryTime DATETIME,
    OrderID INT,
    RiderID INT,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (RiderID) REFERENCES Riders(RiderID)
);
