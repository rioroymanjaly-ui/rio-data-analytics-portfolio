# Food Delivery Database

MSc coursework project for **Enterprise Data Warehouses and Database Management Systems**.

I designed a relational database for a food-delivery service and used SQL to answer operational and business questions.

## What I built

The database contains eight main tables:

- Customers
- Restaurants
- Riders
- FoodItems
- Orders
- OrderItems
- Payments
- Deliveries

The design separates the main business entities and uses `OrderItems` to resolve the many-to-many relationship between orders and food items.

## Analysis included

I created SQL for:

- restaurant revenue using `JOIN`, `GROUP BY`, `COUNT` and `SUM`
- customer spending classification using `CASE`
- rider performance ranking using the `RANK()` window function
- monthly sales and customer-order summary views
- query performance improvement using an index on `Orders.RestaurantID`

## Why I kept this project

This was one of my MSc assignments and it helped me understand how database design connects directly to reporting and business analysis.

The original submitted report is included in `docs/`.

## Tools

MySQL, SQL, relational modelling, normalization, views, indexing, query analysis
