# Telco Customer Churn Analysis

Python, pandas, visualisation

Verified project results from my existing portfolio records:

- 7,043 customer records prepared and explored
- 5,163 retained customers
- 1,869 churned customers
- customer attributes compared with churn outcomes

The original source notebook/dataset was not recovered from my current file library, so this folder intentionally does **not** recreate or invent the code.
