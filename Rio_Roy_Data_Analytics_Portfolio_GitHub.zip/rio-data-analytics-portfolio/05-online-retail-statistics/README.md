# Online Retail Statistical Analysis

Python, pandas, statistics

Verified project results from my existing portfolio records:

- 397,884 transaction records cleaned and analysed
- UK vs non-UK purchasing difference tested statistically
- p-value approximately 1.17 × 10^-21
- correlation between quantity and transaction value: 0.909
- results communicated with charts and interpretation

The original source notebook/dataset was not recovered from my current file library, so this folder intentionally does **not** recreate or invent the code.
