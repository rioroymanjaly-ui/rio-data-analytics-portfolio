#!/usr/bin/env python3
import sys
import csv

reader = csv.reader(sys.stdin)

for row in reader:
    try:
        if row[0] == "transaction_id":
            continue

        country = row[6]
        revenue = float(row[12])

        print(f"{country}\t{revenue}")
    except Exception:
        continue
