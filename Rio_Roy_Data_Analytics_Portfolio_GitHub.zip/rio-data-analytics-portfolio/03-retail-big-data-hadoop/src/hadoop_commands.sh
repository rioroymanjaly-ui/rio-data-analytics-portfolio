# Hadoop commands used in the project

hdfs dfs -mkdir /bda_retail

hdfs dfs -put retail_transactions_bigdata.csv /bda_retail/

hdfs dfs -ls -h /bda_retail/

hdfs fsck /bda_retail/retail_transactions_bigdata.csv -files -blocks -locations

# Hadoop Streaming output was written to:
# /bda_retail/output_country_revenue
