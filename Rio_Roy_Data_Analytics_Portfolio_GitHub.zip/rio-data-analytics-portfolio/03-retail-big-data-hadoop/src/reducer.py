#!/usr/bin/env python3
import sys

current_country = None
current_total = 0.0

for line in sys.stdin:
    try:
        country, revenue = line.strip().split("\t")
        revenue = float(revenue)

        if current_country == country:
            current_total += revenue
        else:
            if current_country is not None:
                print(f"{current_country}\t{current_total:.2f}")

            current_country = country
            current_total = revenue
    except Exception:
        continue

if current_country is not None:
    print(f"{current_country}\t{current_total:.2f}")
