# Retail Big Data Processing with Hadoop

MSc coursework project for **Big Data Analytics**.

I used Hadoop, HDFS, YARN and Hadoop Streaming MapReduce to process a simulated retail transaction dataset.

## Dataset

- 4,473,864 transaction records
- approximately 450 MB
- stored in HDFS as four blocks
- HDFS status checked as healthy

The dataset included transaction, product, country, quantity, price, discount, payment method, purchase date and revenue fields.

## MapReduce task

The business question was simple:

> How much revenue was generated in each country?

The Python mapper extracts country and revenue from each transaction. The reducer aggregates revenue by country.

## Machine-learning extension

I also used a 300,000-row sample for a Linear Regression revenue model:

- 240,000 training rows
- 60,000 testing rows
- R² = 0.9899

The model used transaction information including quantity, unit price, discount, country, category, payment method and date-derived features.

## What I learned

This project helped me understand the difference between distributed storage and processing, how MapReduce works as a batch-processing model, and where Spark would make more sense for repeated analytics.

The original submitted assignment is included in `docs/`.
